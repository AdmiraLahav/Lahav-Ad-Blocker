
// Minimal cosmetic filtering via CSS selectors + user-defined selectors.
// Only activates when 'enabled' flag is true in storage.

(function () {
  const DEFAULT_SELECTORS = [
    "#ad", ".ad", ".ads", ".advert", ".advertisement",
    "[id*='ad-container' i]", "[class*='ad-container' i]",
    "[id^='google_ads_']", "iframe[src*='doubleclick']",
    "iframe[src*='googlesyndication']",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-display-ad-renderer",
    ".ytp-ad-module",
    "div[id^='ad-slot-']",
    "div[class*='sponsored' i]",
    "[data-ad], [data-ad-client], [data-ad-slot]"
  ];

  const state = { enabled: true, customSelectors: [] };

  function buildCss(selectors) {
    if (!selectors || !selectors.length) return "";
    return selectors.map(s => `${s} { display: none !important; }`).join("\n");
  }

  function applyStyles() {
    if (!state.enabled) return;
    const styleId = "__mv3_adblock_css__";
    let style = document.getElementById(styleId);
    if (!style) {
      style = document.createElement("style");
      style.id = styleId;
      style.type = "text/css";
      document.documentElement.appendChild(style);
    }
    const allSelectors = Array.from(new Set([...DEFAULT_SELECTORS, ...state.customSelectors]));
    style.textContent = buildCss(allSelectors);
  }

  // Load settings
  chrome.storage.sync.get({ enabled: true, customSelectors: [] }, (cfg) => {
    state.enabled = !!cfg.enabled;
    state.customSelectors = Array.isArray(cfg.customSelectors) ? cfg.customSelectors : [];
    applyStyles();
  });

  // React to settings changes (e.g., toggled in popup or updated selectors in options)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    if (changes.enabled) state.enabled = !!changes.enabled.newValue;
    if (changes.customSelectors) state.customSelectors = changes.customSelectors.newValue || [];
    // Clear styles if disabled
    if (!state.enabled) {
      const style = document.getElementById("__mv3_adblock_css__");
      if (style) style.textContent = "";
      return;
    }
    applyStyles();
  });
})();
